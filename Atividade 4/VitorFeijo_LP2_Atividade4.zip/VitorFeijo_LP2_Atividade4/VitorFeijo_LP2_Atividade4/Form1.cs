﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VitorFeijo_LP2_Atividade4
{
    public partial class Ptriangulo : Form
    {
        double valorA, valorB, valorC;

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
            txtClassificacao.Clear();
            txtA.Focus();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtA.Text, out valorA) || valorA <= 0 || !double.TryParse(txtB.Text, out valorB) || valorB <= 0 || !double.TryParse(txtC.Text, out valorC) || valorC <= 0)
            {
                MessageBox.Show("Insira valores numéricos maiores que zero");
                txtA.Focus();
                return;
            }
            if ((valorA + valorB > valorC) && (valorA + valorC > valorB) && (valorB + valorC > valorA))
            {
                if (valorA == valorB && valorA == valorC)
                {
                    txtClassificacao.Text = "Triângulo Equilátero";
                }
                else if (valorA == valorB || valorA == valorC || valorB == valorC)
                {
                    txtClassificacao.Text = "Triângulo Isósceles";
                }
                else
                {
                    txtClassificacao.Text = "Triângulo Escaleno";
                }
            }
            else
            {
                MessageBox.Show("Os valores informados não formam um triângulo");
                txtA.Focus();
            }

        }

        public Ptriangulo()
        {
            InitializeComponent();
        }

        
    }


}
