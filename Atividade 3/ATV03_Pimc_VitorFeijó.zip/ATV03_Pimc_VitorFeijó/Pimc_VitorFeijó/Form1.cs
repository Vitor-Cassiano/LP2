﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc_VitorFeijó
{
    public partial class Pimc : Form
    {
        double peso, altura, IMC;

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            try
            {
                peso = Convert.ToDouble(mskbxPeso.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Insira um peso válido");
                mskbxPeso.Focus();
            }

        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            try
            {
                altura = Convert.ToDouble(mskbxAltura.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Insira uma altura válida");
                mskbxAltura.Focus();
            }

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            IMC = peso / Math.Pow(altura, 2);
            IMC = Math.Round(IMC, 1);
            txtIMC.Text = IMC.ToString();
            if (IMC < 18.5)
            { 
                MessageBox.Show("Magreza");
            }
            else if ((IMC >= 18.5) && (IMC <= 24.9))
            {
                MessageBox.Show("Normal");
            }
            else if ((IMC >= 25.0) && (IMC <= 29.9))
            {
                MessageBox.Show("Sobrepeso, Obesidade grau I");
            }
            else if ((IMC >= 30.0) && (IMC <= 39.9))
            {
                MessageBox.Show("Obesidade, Obesidade grau II");
            } 
            else if (IMC > 40.0)
            {
                MessageBox.Show("Obesidade Grave, Obesidade grau III");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPeso.Clear();
            mskbxAltura.Clear();
            txtIMC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Pimc()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
