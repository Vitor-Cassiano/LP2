﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void lblMatricula_Click(object sender, EventArgs e)
        {

        }

        private void lblNome_Click(object sender, EventArgs e)
        {

        }

        private void lblSalarioHora_Click(object sender, EventArgs e)
        {

        }

        private void lblDataEntradaEmpresa_Click(object sender, EventArgs e)
        {

        }

        private void btnInstanciar1_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista();

            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtSalario.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtHora.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtFalta.Text);

            MessageBox.Show("Nome:" + objHorista.NomeEmpregado +"\n" +
                    "Matrícula:" + objHorista.Matricula + "\n" +"Tempo Trabalho:" 
                    + objHorista.TempoTrabalho() + "\n" +"Salário:" +
                    objHorista.SalarioBruto().ToString("N2"));

        }
    }
}
