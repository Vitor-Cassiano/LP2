﻿namespace PLoops
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtNome = new TextBox();
            lblNome = new Label();
            Matricula = new Label();
            txtMatricula = new TextBox();
            label2 = new Label();
            txtProducao = new TextBox();
            label3 = new Label();
            txtSalarioBase = new TextBox();
            label4 = new Label();
            txtGratif = new TextBox();
            btnCalcular = new Button();
            SuspendLayout();
            // 
            // txtNome
            // 
            txtNome.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtNome.Location = new Point(155, 35);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(247, 33);
            txtNome.TabIndex = 0;
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblNome.Location = new Point(86, 38);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(63, 25);
            lblNome.TabIndex = 1;
            lblNome.Text = "Nome";
            // 
            // Matricula
            // 
            Matricula.AutoSize = true;
            Matricula.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Matricula.Location = new Point(57, 91);
            Matricula.Name = "Matricula";
            Matricula.Size = new Size(92, 25);
            Matricula.TabIndex = 3;
            Matricula.Text = "Matricula";
            // 
            // txtMatricula
            // 
            txtMatricula.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtMatricula.Location = new Point(155, 88);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(247, 33);
            txtMatricula.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(57, 144);
            label2.Name = "label2";
            label2.Size = new Size(93, 25);
            label2.TabIndex = 5;
            label2.Text = "Produção";
            // 
            // txtProducao
            // 
            txtProducao.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtProducao.Location = new Point(155, 141);
            txtProducao.Name = "txtProducao";
            txtProducao.Size = new Size(247, 33);
            txtProducao.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(70, 194);
            label3.Name = "label3";
            label3.Size = new Size(70, 25);
            label3.TabIndex = 7;
            label3.Text = "Salário";
            // 
            // txtSalarioBase
            // 
            txtSalarioBase.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtSalarioBase.Location = new Point(155, 191);
            txtSalarioBase.Name = "txtSalarioBase";
            txtSalarioBase.Size = new Size(247, 33);
            txtSalarioBase.TabIndex = 6;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(37, 248);
            label4.Name = "label4";
            label4.Size = new Size(113, 25);
            label4.TabIndex = 9;
            label4.Text = "Gratificação";
            // 
            // txtGratif
            // 
            txtGratif.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtGratif.Location = new Point(155, 240);
            txtGratif.Name = "txtGratif";
            txtGratif.Size = new Size(247, 33);
            txtGratif.TabIndex = 8;
            // 
            // btnCalcular
            // 
            btnCalcular.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnCalcular.Location = new Point(502, 124);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(165, 78);
            btnCalcular.TabIndex = 10;
            btnCalcular.Text = "Calcular Salário";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // frmExercicio4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnCalcular);
            Controls.Add(label4);
            Controls.Add(txtGratif);
            Controls.Add(label3);
            Controls.Add(txtSalarioBase);
            Controls.Add(label2);
            Controls.Add(txtProducao);
            Controls.Add(Matricula);
            Controls.Add(txtMatricula);
            Controls.Add(lblNome);
            Controls.Add(txtNome);
            Name = "frmExercicio4";
            Text = "frmExercicio4";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNome;
        private Label lblNome;
        private Label Matricula;
        private TextBox txtMatricula;
        private Label label2;
        private TextBox txtProducao;
        private Label label3;
        private TextBox txtSalarioBase;
        private Label label4;
        private TextBox txtGratif;
        private Button btnCalcular;
    }
}