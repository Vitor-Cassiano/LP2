﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string texto = txtPalavra.Text;

            if (texto.Length > 50)
            {
                MessageBox.Show("A sequência não pode ter mais de 50 caracteres");
                this.Focus();
            }

            string ajustada = new string(texto.Replace("", " ").ToLower());

            string reversa = new string(ajustada.Reverse().ToArray());

            if(reversa == ajustada)
            {
                MessageBox.Show("É um palíndromo");
            }
            else
            {
                MessageBox.Show("Não é um palíndromo");
            }
        }
    }
}
