﻿namespace PLoops
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            rchtxtFrase = new RichTextBox();
            btnCalcBranc = new Button();
            btnLetraR = new Button();
            btnParLetra = new Button();
            SuspendLayout();
            // 
            // rchtxtFrase
            // 
            rchtxtFrase.Location = new Point(79, 45);
            rchtxtFrase.MaxLength = 100;
            rchtxtFrase.Name = "rchtxtFrase";
            rchtxtFrase.Size = new Size(615, 189);
            rchtxtFrase.TabIndex = 0;
            rchtxtFrase.Text = "";
            // 
            // btnCalcBranc
            // 
            btnCalcBranc.Font = new Font("Segoe UI", 12F);
            btnCalcBranc.Location = new Point(53, 306);
            btnCalcBranc.Name = "btnCalcBranc";
            btnCalcBranc.Size = new Size(202, 112);
            btnCalcBranc.TabIndex = 1;
            btnCalcBranc.Text = "Calcule os espaços em branco";
            btnCalcBranc.UseVisualStyleBackColor = true;
            btnCalcBranc.Click += btnCalcBranc_Click;
            // 
            // btnLetraR
            // 
            btnLetraR.Font = new Font("Segoe UI", 12F);
            btnLetraR.Location = new Point(298, 306);
            btnLetraR.Name = "btnLetraR";
            btnLetraR.Size = new Size(200, 112);
            btnLetraR.TabIndex = 2;
            btnLetraR.Text = "Calcule a qtde de letras R";
            btnLetraR.UseVisualStyleBackColor = true;
            btnLetraR.Click += btnLetraR_Click;
            // 
            // btnParLetra
            // 
            btnParLetra.Font = new Font("Segoe UI", 12F);
            btnParLetra.Location = new Point(535, 306);
            btnParLetra.Name = "btnParLetra";
            btnParLetra.Size = new Size(206, 112);
            btnParLetra.TabIndex = 3;
            btnParLetra.Text = "Calcule a qtde de pares de letras";
            btnParLetra.UseVisualStyleBackColor = true;
            btnParLetra.Click += btnParLetra_Click;
            // 
            // frmExercicio1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnParLetra);
            Controls.Add(btnLetraR);
            Controls.Add(btnCalcBranc);
            Controls.Add(rchtxtFrase);
            Name = "frmExercicio1";
            Text = "frmExercicio1";
            ResumeLayout(false);
        }

        #endregion

        private RichTextBox rchtxtFrase;
        private Button btnCalcBranc;
        private Button btnLetraR;
        private Button btnParLetra;
    }
}