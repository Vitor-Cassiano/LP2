﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            string nome = txtNome.Text;
            string matricula = txtMatricula.Text;
            int producao;
            double salarioBase, gratificacao, salarioBruto = 0;
            int B = 0;
            int C = 0;
            int D = 0;
            if (!int.TryParse(txtProducao.Text, out producao))
            {
                MessageBox.Show("Produção inválida. Digite um número inteiro.");
                return;
            }

            if (!double.TryParse(txtSalarioBase.Text, out salarioBase))
            {
                MessageBox.Show("Salário base inválido. Digite um valor numérico.");
                return;
            }

            if (!double.TryParse(txtGratif.Text, out gratificacao))
            {
                MessageBox.Show("Gratificação inválida. Digite um valor numérico.");
                return;
            }



            if (producao >= 100)
            {
                B = 1;
            }

            if (producao >= 120)
            {
                C = 1;
            }

            if (producao >= 150)
            {
                D = 1;
            }

            if (salarioBruto > 7000 && !(producao >= 150 && gratificacao > 0))
            {
                salarioBruto = 7000.00;
            }

            salarioBruto = salarioBase + salarioBase
                * (0.05 * B + 0.1 * C + 0.1 * D) + gratificacao;
            MessageBox.Show(
            $"Nome: {nome}\n" +
            $"Matrícula: {matricula}\n" +
            $"Produção: {producao}\n" +
            $"Salário Bruto: R$ {salarioBruto:F2}");
        }

    }
}
