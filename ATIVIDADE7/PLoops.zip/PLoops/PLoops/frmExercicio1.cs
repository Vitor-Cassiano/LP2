﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnCalcBranc_Click(object sender, EventArgs e)
        {
            int contBranc = 0;

            foreach (char c in rchtxtFrase.Text)
            {
                if (char.IsWhiteSpace(c))
                {
                    contBranc++;
                }
            }
            MessageBox.Show("A qtde de espaços em branco é: "+contBranc);

        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            int contR = 0;
            int contador = 0;

            while (contador < rchtxtFrase.Text.Length)
            {
                if (rchtxtFrase.Text[contador] == 'R' || rchtxtFrase.Text[contador] == 'r')
                {
                    contR++;
                }
                contador++;
            }
            MessageBox.Show("A qtde de letras R é: "+contR);
        }

        private void btnParLetra_Click(object sender, EventArgs e)
        {
            int contPar = 0;

            for (int i = 0;i<(rchtxtFrase.Text.Length - 1); i++)
            {
                if (rchtxtFrase.Text[i+1] == rchtxtFrase.Text[i])
                {
                    contPar++;
                }
            }
            MessageBox.Show("A qtde de par(es) de letra é: "+contPar);
        }
    }
}
