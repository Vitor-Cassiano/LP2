﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio2 : Form
    {
        int n;
        double NumH = 0.00;
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Validated(object sender, EventArgs e)
        {
         
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNumN.Text, out n) || n < 0)
            {
                MessageBox.Show("Digite um número maior que 0");
                this.Focus();
                return;
            }
            for (int i = 1; i <= n; i++)
            {
                NumH += 1.00 / i;
            }
            MessageBox.Show("Número H: " + NumH.ToString("F3"));
        }
    }
}
