﻿namespace PLoops
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtNumN = new TextBox();
            lblN = new Label();
            btnCalcular = new Button();
            SuspendLayout();
            // 
            // txtNumN
            // 
            txtNumN.Font = new Font("Segoe UI", 12F);
            txtNumN.Location = new Point(200, 76);
            txtNumN.Margin = new Padding(2);
            txtNumN.Name = "txtNumN";
            txtNumN.Size = new Size(251, 29);
            txtNumN.TabIndex = 1;
            // 
            // lblN
            // 
            lblN.AutoSize = true;
            lblN.Font = new Font("Segoe UI", 11F);
            lblN.Location = new Point(60, 79);
            lblN.Margin = new Padding(2, 0, 2, 0);
            lblN.Name = "lblN";
            lblN.Size = new Size(133, 20);
            lblN.TabIndex = 3;
            lblN.Text = "Digite o numero N";
            // 
            // btnCalcular
            // 
            btnCalcular.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnCalcular.Location = new Point(183, 155);
            btnCalcular.Margin = new Padding(2);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(130, 43);
            btnCalcular.TabIndex = 4;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // frmExercicio2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(560, 270);
            Controls.Add(btnCalcular);
            Controls.Add(lblN);
            Controls.Add(txtNumN);
            Margin = new Padding(2);
            Name = "frmExercicio2";
            Text = "frmExercicio2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox txtNumN;
        private Label lblN;
        private Button btnCalcular;
    }
}