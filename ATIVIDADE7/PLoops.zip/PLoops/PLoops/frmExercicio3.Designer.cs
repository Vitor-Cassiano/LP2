﻿namespace PLoops
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblPalindromo = new Label();
            txtPalavra = new TextBox();
            btnVerificar = new Button();
            SuspendLayout();
            // 
            // lblPalindromo
            // 
            lblPalindromo.AutoSize = true;
            lblPalindromo.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblPalindromo.Location = new Point(238, 53);
            lblPalindromo.Name = "lblPalindromo";
            lblPalindromo.Size = new Size(192, 25);
            lblPalindromo.TabIndex = 0;
            lblPalindromo.Text = "Digite a palavra/frase";
            // 
            // txtPalavra
            // 
            txtPalavra.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtPalavra.Location = new Point(114, 90);
            txtPalavra.Name = "txtPalavra";
            txtPalavra.Size = new Size(452, 33);
            txtPalavra.TabIndex = 1;
            // 
            // btnVerificar
            // 
            btnVerificar.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnVerificar.Location = new Point(238, 208);
            btnVerificar.Name = "btnVerificar";
            btnVerificar.Size = new Size(167, 59);
            btnVerificar.TabIndex = 2;
            btnVerificar.Text = "Verificar";
            btnVerificar.UseVisualStyleBackColor = true;
            btnVerificar.Click += btnVerificar_Click;
            // 
            // frmExercicio3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnVerificar);
            Controls.Add(txtPalavra);
            Controls.Add(lblPalindromo);
            Name = "frmExercicio3";
            Text = "frmExercicio3";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblPalindromo;
        private TextBox txtPalavra;
        private Button btnVerificar;
    }
}