﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumeros_Click(object sender, EventArgs e)
        {
            int contanum = 0;
            int contador = 0;

            while (contador < rchtxtFrase.Text.Length) 
            {
                if (char.IsNumber(rchtxtFrase.Text[contador]))
                {
                    contanum++;
                }
                contador++; //contador+=1
            }
            MessageBox.Show("Quantidade de números:"+contanum);
        }

        private void btnEspacoBranco_Click(object sender, EventArgs e)
        {
            int posicao = 0;

            for (int i = 0; i < rchtxtFrase.TextLength; i++) 
            { 
                if (char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    posicao = i+1;
                    break;
                }
            }
            MessageBox.Show("Posição 1º caracter em branco: " + posicao);
        }

        private void btnContarLetras_Click(object sender, EventArgs e)
        {
            int contLetra = 0;
            
            foreach(var c in rchtxtFrase.Text)
            {
                if (char.IsLetter(c)) 
                {
                    contLetra++;
                }
            }
            MessageBox.Show("Quantidade letras: "+contLetra);
        }
    }
}
