﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pvestibular02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnReceberDados_Click(object sender, EventArgs e)
        {
            int[,] vetor = new int[2,5];
            string auxiliar = "";
            int total1 =0, total2=0, totalGeral=0;
            string saida = "";

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 5; j++) 
                {
                    auxiliar = Interaction.InputBox($"Digite o total do curso {i+1} do Ano {j+1}:",
                        "Entrada de dados");
                    if(!int.TryParse(auxiliar, out vetor[i,j]) ||  vetor[i,j] < 0)
                    {
                        MessageBox.Show("Digite um número válido");
                        this.Focus();
                        return;
                    }
                    if (i == 0)
                    {
                        total1 += vetor[i, j];
                       
                    }
                    else 
                    {
                        total2 += vetor[i, j];

                    }
                }
                MessageBox.Show($"Total do curso 1: " + total1);
            }
            MessageBox.Show($"Total do curso 2: " + total2);
            totalGeral = total1 + total2;
            MessageBox.Show($"Total Geral: "+ totalGeral);

        }
    }
}
