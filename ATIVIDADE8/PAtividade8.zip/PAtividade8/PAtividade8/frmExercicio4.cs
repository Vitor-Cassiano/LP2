﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade8
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] vetor = new string[10];
            int[] vetor2 = new int[10];
            string auxiliar = "";

            for (int i = 0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox("Digite o nome completo", "Entrada de dados");

                if (auxiliar.Replace(" ", "").Length == 0)
                {
                    MessageBox.Show("Valor inválido!");
                    i--;
                }
                else
                {
                    vetor[i] = auxiliar;
                    vetor2[i] = auxiliar.Replace(" ", "").Length;
                }
            }
            for (int i = 0; i < 10; i++)
            {
                lstbxNomes.Items.Add($"o nome {vetor[i]} tem {vetor2[i]} caracteres");
            }
        }
    }
}
