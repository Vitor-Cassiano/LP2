﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VITOR_FEIJÓ_LP2_ATIVIDADE2
{
    public partial class PCalc : Form
    {
        double numero1, numero2, resultado;

        public PCalc()
        {
            InitializeComponent();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtResultado.Text = resultado.ToString("N2");
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtResultado.Text = resultado.ToString("N2");
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtResultado.Text = resultado.ToString("N2");
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero2.Text, out numero2) || numero2 ==0)
            {
                MessageBox.Show("Número inválido");
                txtNumero2.Focus();
            }

        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out numero1)) 
            {
                MessageBox.Show("Número inválido");
                txtNumero1.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
           txtNumero1.Clear();
           txtNumero2.Clear();
           txtResultado.Clear();
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            resultado = numero1 / numero2;
            txtResultado.Text = resultado.ToString("N2");
        }

    }
}
